﻿namespace HuajiTech.Mirai.ApiHandlers
{
    /// <summary>
    /// 提供与 API 通过 HTTP 交互的方法
    /// </summary>
    internal static partial class ApiMethods
    {
    }
}